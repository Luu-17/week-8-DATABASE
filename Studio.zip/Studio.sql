-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: testingdb
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artist`
--

DROP TABLE IF EXISTS `artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artist` (
  `Artist_ID` int NOT NULL AUTO_INCREMENT,
  `StageName` varchar(100) DEFAULT NULL,
  `realName` varchar(100) DEFAULT NULL,
  `based` varchar(100) DEFAULT NULL,
  `distributionType` varchar(100) DEFAULT NULL,
  `dist_ID` int DEFAULT NULL,
  PRIMARY KEY (`Artist_ID`),
  KEY `dist_ID` (`dist_ID`),
  CONSTRAINT `artist_ibfk_1` FOREIGN KEY (`dist_ID`) REFERENCES `distributor` (`dist_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=141005 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist`
--

LOCK TABLES `artist` WRITE;
/*!40000 ALTER TABLE `artist` DISABLE KEYS */;
INSERT INTO `artist` VALUES (141000,'OX','Simon Mphaphuli','Limpopo','subscription',5),(141001,'LaTrevor','Maribe Trevor Mogkubo','Gauteng','contract',2),(141002,'Nuff-God','Tshepo Lepere','North West','subscription',4),(141003,'MBL Legitmate','Lukhanyo Mzanywa','Gauteng','contract',2),(141004,'Uncle Mlhonizer','Lehlohonolo Blessing Khumalo','Lesetho','subscription',4);
/*!40000 ALTER TABLE `artist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distributor`
--

DROP TABLE IF EXISTS `distributor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `distributor` (
  `dist_ID` int NOT NULL AUTO_INCREMENT,
  `distributorName` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `pay_period` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`dist_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distributor`
--

LOCK TABLES `distributor` WRITE;
/*!40000 ALTER TABLE `distributor` DISABLE KEYS */;
INSERT INTO `distributor` VALUES (1,'DISTROKID','AMERICA','3-months'),(2,'V Music group','South Africa','12-months'),(4,'Ditto','United-Kingdom','3-months'),(5,'Amuse','Sweden','3-months');
/*!40000 ALTER TABLE `distributor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `music`
--

DROP TABLE IF EXISTS `music`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `music` (
  `song_ID` int NOT NULL AUTO_INCREMENT,
  `nameofsong` varchar(100) DEFAULT NULL,
  `genre` varchar(100) DEFAULT NULL,
  `dist_ID` int DEFAULT NULL,
  `Artist_ID` int DEFAULT NULL,
  `doR` date DEFAULT NULL,
  PRIMARY KEY (`song_ID`),
  KEY `dist_ID` (`dist_ID`),
  KEY `Artist_ID` (`Artist_ID`),
  CONSTRAINT `music_ibfk_1` FOREIGN KEY (`dist_ID`) REFERENCES `distributor` (`dist_ID`),
  CONSTRAINT `music_ibfk_2` FOREIGN KEY (`Artist_ID`) REFERENCES `artist` (`Artist_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `music`
--

LOCK TABLES `music` WRITE;
/*!40000 ALTER TABLE `music` DISABLE KEYS */;
INSERT INTO `music` VALUES (1,'Daily Nightmare','HipHop',2,141000,'2023-07-20'),(2,'Daily Nightmare','HipHop',2,141003,'2023-07-20'),(3,'The Ballers Dream','Hip Hop',2,141003,'2023-04-06'),(4,'The Weekend','Hip Hop',2,141003,'2023-05-23'),(5,'Ride With Me','Ama Piano',4,141004,'2023-09-16'),(6,'Be Careful','Hip-Hop',2,141001,'2023-07-15'),(7,'Dead To Me','Hip-Hop',2,141001,'2023-07-15'),(8,'Blue Tick (Valhalla)','Hip-Hop',2,141001,'2023-07-15'),(9,'365 C Walk','Hip-Hop',2,141001,'2023-07-15'),(10,'SofT Life (Bonus Track)','Hip-Hop',2,141001,'2023-07-15'),(11,'Dollar Step (Antidote)','Hip-Hop',4,141002,'2024-12-16'),(12,'Pitori Kamo Jozi','Hip-Hop',4,141002,'2024-08-10'),(13,'City Lyts','Hip-Hop',4,141002,'2024-05-22'),(14,'Pull Up','Hip-Hop',4,141002,'2023-11-03'),(15,'Be Without You','Hip-Hop',4,141002,'2023-06-15'),(16,'SGS','Dancehall',2,141003,NULL);
/*!40000 ALTER TABLE `music` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 14:42:38
